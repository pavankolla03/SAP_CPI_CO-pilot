import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
Message processData(Message message) {
    def event = new JsonSlurper().parseText(message.getBody(String))
    if (event.type != 'relay.order.requested.v1' || !(event.payload instanceof Map)) throw new IllegalArgumentException('Unsupported event contract')
    def order = event.payload
    if (!(order.amount instanceof Number) || !(order.quantity instanceof Number) || order.amount < 0 || order.quantity <= 0) throw new IllegalArgumentException('Invalid order values')
    message.setHeader('SAP_ApplicationID', event.id)
    message.setBody(JsonOutput.toJson([id:event.id, type:'relay.order.validated.v1', payload:[orderId:event.id,total:order.amount*order.quantity]]))
    return message
}
