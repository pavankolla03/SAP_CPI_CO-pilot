import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
Message processData(Message message) {
    def event = new JsonSlurper().parseText(message.getBody(String))
    if (event.type != 'relay.order.validated.v1' || !(event.payload instanceof Map)) throw new IllegalArgumentException('Unsupported event contract')
    message.setHeader('SAP_ApplicationID', event.id)
    message.setBody(JsonOutput.toJson([id:event.id,type:'relay.fulfillment.requested.v1',payload:[externalOrderId:event.payload.orderId,netAmount:event.payload.total]]))
    return message
}
