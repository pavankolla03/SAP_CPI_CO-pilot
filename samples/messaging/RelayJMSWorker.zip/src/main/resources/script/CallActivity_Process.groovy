import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
Message processData(Message message) {
    def body = new JsonSlurper().parseText(message.getBody(String))
    int retries = (message.getHeader('SAPJMSRetries', Object) ?: 0) as int
    if (retries < ((body.failUntilRetry ?: 0) as int)) throw new IllegalStateException('Synthetic DEV transient failure')
    if (!(body.payload instanceof Map)) throw new IllegalArgumentException('Invalid payload')
    message.setHeader('SAP_ApplicationID', body.id)
    def log = messageLogFactory.getMessageLog(message)
    if (log != null) { log.addCustomHeaderProperty('RelayEventId', body.id); log.addCustomHeaderProperty('RelayRetryCount', retries.toString()); log.addCustomHeaderProperty('RelayOutcome', 'PROCESSED') }
    message.setBody(JsonOutput.toJson([id:body.id, status:'PROCESSED', retries:retries, payload:body.payload]))
    return message
}
