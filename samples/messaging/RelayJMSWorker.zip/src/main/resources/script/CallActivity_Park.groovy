import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
Message processData(Message message) {
    def id = 'unparseable'
    try {
        def body = new JsonSlurper().parseText(message.getBody(String))
        if (body instanceof Map && body.id instanceof String && body.id ==~ /[A-Za-z0-9_-]{1,64}/) id = body.id
    } catch (Exception ignored) { }
    def log = messageLogFactory.getMessageLog(message)
    if (log != null) { log.addCustomHeaderProperty('RelayEventId', id); log.addCustomHeaderProperty('RelayOutcome', 'PARKED') }
    message.setHeader('SAP_ApplicationID', id)
    return message
}
