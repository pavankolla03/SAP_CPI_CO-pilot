import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
Message processData(Message message) {
        int retries = (message.getHeader('SAPJMSRetries', Object) ?: 0) as int
        message.setProperty('relayPark', retries >= 3 ? 'true' : 'false')
        return message
    }
    