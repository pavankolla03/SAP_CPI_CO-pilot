import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
Message processData(Message message) {
    def body = new JsonSlurper().parseText(message.getBody(String))
    message.setHeader('CamelHttpResponseCode', 202)
    message.setHeader('Content-Type', 'application/json')
    message.setBody(JsonOutput.toJson([id:body.id,status:'QUEUED']))
    return message
}
