import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
Message processData(Message message) {
    def body = new JsonSlurper().parseText(message.getBody(String))
    if (!(body instanceof Map) || !(body.id instanceof String) || !(body.id ==~ /[A-Za-z0-9_-]{1,64}/)) throw new IllegalArgumentException('Invalid event ID')
    if (!(body.payload instanceof Map)) throw new IllegalArgumentException('payload must be an object')
    def failures = body.failUntilRetry ?: 0
    if (!(failures instanceof Number) || failures < 0 || failures > 3 || failures != failures.intValue()) throw new IllegalArgumentException('failUntilRetry must be 0..3 for DEV testing')
    message.setHeader('SAP_ApplicationID', body.id)
    message.setBody(JsonOutput.toJson([id:body.id, type:'relay.order.requested.v1', payload:body.payload, failUntilRetry:failures]))
    return message
}
