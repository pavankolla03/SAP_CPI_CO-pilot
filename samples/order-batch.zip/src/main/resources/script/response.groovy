import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonOutput
Message processData(Message message) {
    def xml = new XmlSlurper().parseText(message.getBody(String))
    def results = xml.depthFirst().findAll { it.name() == 'result' }.collect { item ->
        def row = [id:item.id.text(), status:item.status.text()]
        if (item.total.size()) row.total = new BigDecimal(item.total.text())
        if (item.reason.size()) row.reason = item.reason.text()
        row
    }
    if (results.isEmpty()) throw new IllegalStateException('No gathered results')
    message.setHeader('Content-Type', 'application/json')
    message.setHeader('CamelHttpResponseCode', 200)
    message.setBody(JsonOutput.toJson([orders:results, count:results.size()]))
    return message
}
