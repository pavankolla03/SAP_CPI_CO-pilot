import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
Message processData(Message message) {
    def writer = new StringWriter()
    new MarkupBuilder(writer).result {
        id(message.getProperty('relayOrderId'))
        status('REVIEW')
        total(message.getProperty('relayTotal'))
    }
    message.setBody(writer.toString())
    return message
}
