import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
Message processData(Message message) {
    def validation = null
    def caught = message.getProperty('CamelExceptionCaught')
    def allowed = ['Invalid JSON','Invalid order count','Expected order object','Invalid order ID','Duplicate order ID']
    for (int i=0; caught != null && i<12; i++) {
        def description = caught.getMessage() ?: ''
        for (String reason : allowed) {
            if (description.contains('RELAY_VALIDATION:' + reason)) validation = reason
        }
        caught = caught.getCause()
    }
    message.setHeader('Content-Type', 'application/json')
    message.setHeader('CamelHttpResponseCode', validation ? 400 : 500)
    message.setBody(JsonOutput.toJson([error:validation ?: 'Batch processing failed', handler:'exception_subprocess']))
    return message
}
