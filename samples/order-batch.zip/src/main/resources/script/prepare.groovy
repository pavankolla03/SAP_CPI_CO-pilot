import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
Message processData(Message message) {
    def input
    try { input = new JsonSlurper().parseText(message.getBody(String)) }
    catch (Exception e) { throw new IllegalArgumentException('RELAY_VALIDATION:Invalid JSON') }
    if (!(input instanceof Map) || !(input.orders instanceof List) || input.orders.size() < 1 || input.orders.size() > 100) {
        throw new IllegalArgumentException('RELAY_VALIDATION:Invalid order count')
    }
    def seen = new HashSet()
    def rows = []
    input.orders.eachWithIndex { order, index ->
        if (!(order instanceof Map)) throw new IllegalArgumentException('RELAY_VALIDATION:Expected order object')
        def id = order.id
        if (!(id instanceof String) || !(id ==~ /[A-Za-z0-9_-]{1,64}/)) throw new IllegalArgumentException('RELAY_VALIDATION:Invalid order ID')
        if (!seen.add(id)) { throw new IllegalArgumentException('RELAY_VALIDATION:Duplicate order ID') }
        def amount = order.amount; def quantity = order.quantity
        def valid = amount instanceof Number && quantity instanceof Number
        if (valid) valid = amount >= 0 && amount <= 1000000000 && quantity >= 1 && quantity <= 10000 && quantity == quantity.intValue()
        rows << [id:id, amount:valid ? amount : 0, quantity:valid ? quantity : 0, valid:valid]
    }
    def writer = new StringWriter()
    new MarkupBuilder(writer).orders {
        rows.each { row -> order { id(row.id); amount(row.amount); quantity(row.quantity); valid(row.valid) } }
    }
    message.setBody(writer.toString())
    message.setHeader('Content-Type', 'application/xml')
    return message
}
