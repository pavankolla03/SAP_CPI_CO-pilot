import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
Message processData(Message message) {
    def order = new XmlSlurper().parseText(message.getBody(String)).order
    message.setProperty('relayOrderId', order.id.text())
    def valid = order.valid.text() == 'true'
    def total = new BigDecimal(order.amount.text()) * new BigDecimal(order.quantity.text())
    message.setProperty('relayTotal', total)
    message.setProperty('relayRoute', !valid ? 'REJECTED' : total > 1000 ? 'REVIEW' : 'ACCEPTED')
    return message
}
