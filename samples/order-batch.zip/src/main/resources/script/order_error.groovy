import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
Message processData(Message message) {
    def writer = new StringWriter()
    new MarkupBuilder(writer).result {
        id(message.getProperty('relayOrderId') ?: 'unknown')
        status('ERROR'); reason('Order processing failed')
    }
    message.setBody(writer.toString())
    return message
}
