import com.sap.gateway.ip.core.customdev.util.Message
Message processData(Message message) {
    message.setHeader("Content-Type", "application/json")
    message.setBody('{"status":"ok","artifact":"RelaySmoke20260915"}')
    return message
}
